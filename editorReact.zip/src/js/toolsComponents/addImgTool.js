import React, { useState } from 'react';
import styled from "styled-components";

const StyledImgInput = styled.div`
    width: 100%;
    max-width: 1160px;
    margin: 0 auto; 
    padding-top: 50px;
    padding-bottom: 15px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    .img-container {
        width: 100%;
        img {
            width: 100%;
            height: auto:
        }
    }
    form {
        @media print {
            display: none;
        }
        label {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        }
        input {
            margin-top: 8px;
            background-color: #F8F9F9;
        }
    }
`

function AddImgTool(props) {
    const [imgUrl, setImgUrl] = useState(props.data.contents.imgUrl)

    async function inputFileHandler(event) {
        console.log('hi')
        event.preventDefault();
        let file = event.target.files[0];
        let imageBase64 = await processFile(file);
        setImgUrl(imageBase64)
    }

    // главная логика
    function processFile(file) {
      return new Promise((resolve, reject) => {
        if (file && /(jpeg|png)/.test(file.type)) {
          const reader = new FileReader();
          reader.readAsDataURL(file); // ключевой метод
          reader.onerror = error => { 
            console.log(error);
            reject(error);
           };
          reader.onload = () => {
            resolve(reader.result);
          }
        }
      });
    }

    return(
        <StyledImgInput>
            <div className='img-container'>
                <img
                    src={imgUrl}
                    data-value-content
                    data-key='imgUrl' />
            </div>
            <form>
                <label>
                    Загрузить изображение:
                    <input 
                        type="file"
                        onChange={(event) => inputFileHandler(event)} />
                </label>
            </form>
        </StyledImgInput>
    )
}

export default AddImgTool